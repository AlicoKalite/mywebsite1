from flask import Flask, render_template, request, send_file, make_response
from PIL import Image
from pptx import Presentation
from pdf2image import convert_from_path
import os, zipfile

# ppt → pptx Windows + PowerPoint gerektirdiği için opsiyonel import
try:
    from win32com import client
    WIN32COM_AVAILABLE = True
except ImportError:
    WIN32COM_AVAILABLE = False

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ------------------------
# Ana Menü
# ------------------------
@app.route("/")
def index():
    return render_template("index.html")

# ------------------------
# Resim Menüsü
# ------------------------
@app.route("/resim")
def resim():
    return render_template("resim.html")

@app.route("/resim/png_to_jpg", methods=["GET","POST"])
def png_to_jpg():
    if request.method=="POST":
        files = request.files.getlist("images")
        converted=[]
        for file in files:
            if file.filename.lower().endswith(".png"):
                path=os.path.join(UPLOAD_FOLDER,file.filename)
                file.save(path)
                img = Image.open(path).convert("RGB")
                new_path = os.path.join(UPLOAD_FOLDER,file.filename.rsplit(".",1)[0]+".jpg")
                img.save(new_path,"JPEG")
                converted.append(new_path)
        zip_path=os.path.join(UPLOAD_FOLDER,"png_to_jpg.zip")
        with zipfile.ZipFile(zip_path,"w") as zipf:
            for f in converted:
                zipf.write(f, os.path.basename(f))
        response = make_response(send_file(zip_path, as_attachment=True))
        response.headers["Content-Disposition"]="attachment; filename=png_to_jpg.zip"
        response.headers["Content-Type"]="application/zip"
        return response
    return render_template("png_to_jpg.html")

@app.route("/resim/jpg_to_png", methods=["GET","POST"])
def jpg_to_png():
    if request.method=="POST":
        files = request.files.getlist("images")
        converted=[]
        for file in files:
            if file.filename.lower().endswith(".jpg") or file.filename.lower().endswith(".jpeg"):
                path=os.path.join(UPLOAD_FOLDER,file.filename)
                file.save(path)
                img = Image.open(path)
                new_path = os.path.join(UPLOAD_FOLDER,file.filename.rsplit(".",1)[0]+".png")
                img.save(new_path,"PNG")
                converted.append(new_path)
        zip_path=os.path.join(UPLOAD_FOLDER,"jpg_to_png.zip")
        with zipfile.ZipFile(zip_path,"w") as zipf:
            for f in converted:
                zipf.write(f, os.path.basename(f))
        response = make_response(send_file(zip_path, as_attachment=True))
        response.headers["Content-Disposition"]="attachment; filename=jpg_to_png.zip"
        response.headers["Content-Type"]="application/zip"
        return response
    return render_template("jpg_to_png.html")

@app.route("/resim/resize", methods=["GET","POST"])
def resize():
    if request.method=="POST":
        files = request.files.getlist("images")
        percent = int(request.form["percent"])
        converted=[]
        for file in files:
            path=os.path.join(UPLOAD_FOLDER,file.filename)
            file.save(path)
            img = Image.open(path)
            new_size=(int(img.width*percent/100), int(img.height*percent/100))
            img=img.resize(new_size)
            new_path = os.path.join(UPLOAD_FOLDER,file.filename)
            img.save(new_path)
            converted.append(new_path)
        zip_path=os.path.join(UPLOAD_FOLDER,"resized.zip")
        with zipfile.ZipFile(zip_path,"w") as zipf:
            for f in converted:
                zipf.write(f, os.path.basename(f))
        response = make_response(send_file(zip_path, as_attachment=True))
        response.headers["Content-Disposition"]="attachment; filename=resized.zip"
        response.headers["Content-Type"]="application/zip"
        return response
    return render_template("resize.html")

# ------------------------
# Office Menüsü
# ------------------------
@app.route("/office")
def office():
    return render_template("office.html")

# PDF → PPTX (modern drag & drop + çoklu dosya + ilerleme barı)
@app.route("/office/pdf_to_pptx", methods=["GET","POST"])
def pdf_to_pptx():
    if request.method=="POST":
        files = request.files.getlist("files")
        converted=[]
        for file in files:
            if file.filename.lower().endswith(".pdf"):
                path=os.path.join(UPLOAD_FOLDER,file.filename)
                file.save(path)
                # PDF sayfalarını resim olarak al
                pages = convert_from_path(path)  # gerekirse Windows'ta poppler_path belirt
                prs = Presentation()
                for page in pages:
                    slide = prs.slides.add_slide(prs.slide_layouts[6])
                    img_path = os.path.join(UPLOAD_FOLDER,"temp_page.png")
                    page.save(img_path,"PNG")
                    slide.shapes.add_picture(img_path,0,0,width=prs.slide_width,height=prs.slide_height)
                    os.remove(img_path)
                new_path = os.path.join(UPLOAD_FOLDER,file.filename.rsplit(".",1)[0]+".pptx")
                prs.save(new_path)
                converted.append(new_path)
        zip_path=os.path.join(UPLOAD_FOLDER,"pdf_to_pptx.zip")
        with zipfile.ZipFile(zip_path,"w") as zipf:
            for f in converted:
                zipf.write(f, os.path.basename(f))
        response = make_response(send_file(zip_path, as_attachment=True))
        response.headers["Content-Disposition"]="attachment; filename=pdf_to_pptx.zip"
        response.headers["Content-Type"]="application/zip"
        return response
    return render_template("pdf_to_pptx.html")

# PPT → PPTX (Windows + PowerPoint yüklü değilse devre dışı)
@app.route("/office/ppt_to_pptx", methods=["GET","POST"])
def ppt_to_pptx():
    if not WIN32COM_AVAILABLE:
        return "<h2>PPT → PPTX dönüştürme Windows + PowerPoint gerektirir.</h2><a href='/office'>Geri</a>"
    if request.method=="POST":
        files=request.files.getlist("files")
        converted=[]
        for file in files:
            if file.filename.lower().endswith(".ppt"):
                path=os.path.join(UPLOAD_FOLDER,file.filename)
                file.save(path)
                ppt_app = client.Dispatch("PowerPoint.Application")
                presentation = ppt_app.Presentations.Open(os.path.abspath(path))
                new_path = os.path.join(UPLOAD_FOLDER,file.filename.rsplit(".",1)[0]+".pptx")
                presentation.SaveAs(os.path.abspath(new_path),24)
                presentation.Close()
                ppt_app.Quit()
                converted.append(new_path)
        zip_path=os.path.join(UPLOAD_FOLDER,"ppt_to_pptx.zip")
        with zipfile.ZipFile(zip_path,"w") as zipf:
            for f in converted:
                zipf.write(f, os.path.basename(f))
        response = make_response(send_file(zip_path, as_attachment=True))
        response.headers["Content-Disposition"]="attachment; filename=ppt_to_pptx.zip"
        response.headers["Content-Type"]="application/zip"
        return response
    return render_template("ppt_to_pptx.html")

# ------------------------
# Çalıştır
# ------------------------
if __name__=="__main__":
    app.run(debug=True)